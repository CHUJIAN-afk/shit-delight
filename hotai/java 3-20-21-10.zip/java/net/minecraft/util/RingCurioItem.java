package net.minecraft.util;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import top.theillusivec4.curios.api.type.capability.ICurio;

public class RingCurioItem extends Item implements ICurio {
    public RingCurioItem(Properties pProperties) {
        super(pProperties);
    }

    @Override
    public ItemStack getStack() {
        return new ItemStack(this);
    }
}
