package net.minecraft.util;

public class ShitDelightUtils {
    public static ShitDelightUtils INSTANCE = new ShitDelightUtils();

    public ShitDelightUtils() {
    }
}
